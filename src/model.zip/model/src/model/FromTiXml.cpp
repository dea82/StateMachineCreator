//
// Created by Andreas Laghamn on 2018-09-09.
//

#include "FromTiXml.hpp"
#include "model/Factory.hpp"
#include "model/IVariables.hpp"
#include "tinyxml.h"

namespace statemachinecreator::model {

IVariables *VariablesFromTiXmlConverter::convert(TiXmlElement *element) {
  auto variables = factory::createVariables();
  for (auto pVariableElement = element->FirstChildElement("Variable"); pVariableElement != 0;
       pVariableElement = pVariableElement->NextSiblingElement("Variable")) {

    variables->AddVariable(pVariableElement->Attribute("name"), pVariableElement->Attribute("value"));
  }
  return variables;
}

}