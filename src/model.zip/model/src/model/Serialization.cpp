#include "Serialization.hpp"
#include "tinyxml.h"
#include "model/IConverter.hpp"

#include <sstream>
namespace statemachinecreator::model {

void VariablesSerializer::serialize(statemachinecreator::model::IVariables *pVariables,
                                    std::string filename) {
  TiXmlDocument doc;
  auto pRoot = new TiXmlElement("root");
  doc.LinkEndChild(pRoot);
  pRoot->LinkEndChild(m_pVariablesToTiXmlConverter->convert(pVariables));

  if (!doc.SaveFile(filename.c_str())) {
    std::stringstream ss;
    ss << "Failed to save file";
    throw(ss);
  }
}

IVariables *VariablesDeserializer::deserialize(std::string /*filename*/) {
  return nullptr;
}

}