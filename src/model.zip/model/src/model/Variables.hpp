#pragma once

#include "model/IVariables.hpp"

namespace statemachinecreator::model {

// TODO: Namespace
class Variables : public IVariables {
 public:
  Variables() = default;

  void AddVariable(const std::string &name, const std::string &value) override {
    variables_.emplace_back(name, value);
  }

  bool Exist(const std::string &name) const override {
    return std::find_if(variables_.begin(), variables_.end(),
                        [&name](const VariableT &variable) { return variable.name == name; })
        != variables_.end();
  }
  VariablesIterator begin() const override { return variables_.begin(); }
  VariablesIterator end() const override { return variables_.end(); }

 private:
  std::vector<VariableT> variables_;
};
}