#include "ToTiXml.hpp"

#include "tinyxml.h"
#include "model/IVariables.hpp"


namespace statemachinecreator::model {

TiXmlElement *VariablesToTiXmlConverter::convert(IVariables *pVariables) {
  auto pVariablesElement = new TiXmlElement("Variables");
  for(const auto & variable : *pVariables) {
    auto pVariableElement = new TiXmlElement("Variable");
    pVariableElement->SetAttribute("name", variable.name.c_str());
    pVariableElement->SetAttribute("value", variable.value.c_str());
    pVariablesElement->LinkEndChild(pVariableElement);
  }
  return pVariablesElement;
}
}
