#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include "model/Factory.hpp"
#include "tinyxml.h"
#include "model/IConverter.hpp"
#include "model/IVariables.hpp"  // TODO: Remove
#include "mock_variables.hpp"
#include <vector>

using ::testing::NiceMock;
using ::testing::_;

namespace statemachinecreator::model {

struct TestVariablesToTiXmlConverter : public ::testing::Test {
  TestVariablesToTiXmlConverter()
      : m_emptyVariablesContainer(),
        m_variablesContainer(),
        m_spToTiXmlConverter(factory::createVariablesToTiXmlConverter()),
        m_spFromTiXmlConverter(factory::createVariablesFromTiXmlConverter()),
        m_spVariables(factory::createVariables()),
        m_mockVariables() {
    m_variablesContainer.emplace_back("my_var1", "my_val1");
    m_variablesContainer.emplace_back("my_var2", "my_val2");
    m_variablesContainer.emplace_back("my_var3", "my_val3");
    ON_CALL(m_mockVariables, begin()).WillByDefault(::testing::Return(m_variablesContainer.begin()));
    ON_CALL(m_mockVariables, end()).WillByDefault(::testing::Return(m_variablesContainer.end()));
  }

  std::vector<IVariables::VariableT> m_emptyVariablesContainer;
  std::vector<IVariables::VariableT> m_variablesContainer;
  IVariablesToTiXmlConverterSP m_spToTiXmlConverter;
  IVariablesFromTiXmlConverterSP m_spFromTiXmlConverter;
  IVariables *m_spVariables;
  NiceMock<MockVariables> m_mockVariables;
};

TEST_F(TestVariablesToTiXmlConverter, convert_empty) {
  ON_CALL(m_mockVariables, begin()).WillByDefault(::testing::Return(m_emptyVariablesContainer.begin()));
  ON_CALL(m_mockVariables, end()).WillByDefault(::testing::Return(m_emptyVariablesContainer.end()));
  auto spTiXml = std::shared_ptr<TiXmlElement>(m_spToTiXmlConverter->convert(&m_mockVariables));
  EXPECT_STREQ(spTiXml->Value(), "Variables");
  EXPECT_TRUE(spTiXml->NoChildren());
}

TEST_F(TestVariablesToTiXmlConverter, convert) {
  auto spTiXml = std::shared_ptr<TiXmlElement>(m_spToTiXmlConverter->convert(&m_mockVariables));
  EXPECT_STREQ(spTiXml->Value(), "Variables");
  EXPECT_FALSE(spTiXml->NoChildren());
  int count = 0;
  for (auto child = spTiXml->FirstChild(); child; child = child->NextSibling())
    count++;
  EXPECT_EQ(count, 3);
  auto spTiXml2 = m_spFromTiXmlConverter->convert(spTiXml.get());
  count = 0;
  for(const auto & variable :  *spTiXml2) {
    EXPECT_EQ(variable.name, m_variablesContainer[count].name);
    EXPECT_EQ(variable.value, m_variablesContainer[count].value);
    ++count;
  }
}

}