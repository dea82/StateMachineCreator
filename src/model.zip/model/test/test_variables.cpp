#include <gtest/gtest.h>
#include <gmock/gmock.h>
#include <memory>

#include "model/Factory.hpp"
#include "model/IVariables.hpp"

namespace statemachinecreator::model {
struct TestVariables : public ::testing::Test {
  TestVariables() : variables_(factory::createVariables()) {}
  std::unique_ptr<IVariables> variables_;

  size_t Size() const {
    size_t i = 0;
    for (const auto &variable : *variables_) {
      (void) variable;
      ++i;
    }
    return i;
  }
};

TEST_F(TestVariables, constructor) {
  EXPECT_EQ(Size(), 0);
}

TEST_F(TestVariables, AddVariableAndExist) {
  EXPECT_FALSE(variables_->Exist("my_var"));
  variables_->AddVariable("my_var", "my_value");
  EXPECT_TRUE(variables_->Exist("my_var"));
  EXPECT_EQ(Size(), 1);
  for (const auto & variable : *variables_) {
    EXPECT_EQ(variable.name, "my_var");
    EXPECT_EQ(variable.value, "my_value");
  }
}

}  // namespace statemachinecreator::model
